package com.UnifiedMentor.FarmerGovtAids;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmerGovtAidsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmerGovtAidsApplication.class, args);
	}

}
