package com.UnifiedMentor.FarmerGovtAids;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmerGovtAidsApplicationTests {

	@Test
	void contextLoads() {
	}

}
