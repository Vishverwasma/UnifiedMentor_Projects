package com.UnifiedMentor.SportsBuddy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportsBuddyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportsBuddyApplication.class, args);
	}

}
