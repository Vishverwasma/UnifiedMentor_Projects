package com.UnifiedMentor.SportsBuddy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportsBuddyApplicationTests {

	@Test
	void contextLoads() {
	}

}
