package com.app.CareerGuidance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareerGuidanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CareerGuidanceApplication.class, args);
	}

}
