package com.app.CareerGuidance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CareerGuidanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
